## ----fit-additive-genetic-ai, warning = FALSE----------------------------
res.animal <- remlf90(fixed  = phe_X ~ 1,
                      random = ~ gg,
                      genetic = list(model = 'add_animal', 
                                     pedigree = globulus[, 1:3],
                                     id = 'self'), 
                      data = globulus)
summary(res.animal)

## ----globulus-se_covar_function, warning = FALSE-------------------------
globulus <- transform(globulus,
                      fam = factor(mum, exclude = 0))

h2fml <- '4*G_3_3_1_1/(G_3_3_1_1+R_1_1)'

res.fml <- remlf90(fixed  = phe_X ~ gg,
                   random = ~ bl + fam,
                   progsf90.options = paste('se_covar_function h2', h2fml),
                   data = globulus)
summary(res.fml)

## ----extract-invAI-------------------------------------------------------
(invAI <- res.fml$reml$invAI)

## ----sqrt-invAI----------------------------------------------------------
sqrt(diag(invAI))

## ----deltamethod-msm-----------------------------------------------------
if (require(msm)) {
  
  h2hat <- with(as.list(res.fml$var[, "Estimated variances"]),
                4*fam/(fam+Residual))
  h2se <- deltamethod(~ 4*x2/(x2+x3),
                      res.fml$var[, "Estimated variances"],
                      invAI)
  cat(paste0('Heritability (delta method): ', 
             round(h2hat, 2), ' (', 
             round(h2se, 2), ')'))
}

## ----simple-model-fit----------------------------------------------------
globulus <- transform(globulus,
                      fam = factor(mum, exclude = 0))

res <- remlf90(fixed  = phe_X ~ 1,
               random = ~ bl + fam,
               data = globulus)

## ----resampling-function-------------------------------------------------

resample_globulus <- function(dat = globulus, N = 100, fit = res) {
  breedR.sample.phenotype(
    fixed = 1,
    random = list(bl = list(nlevels = 15,
                       sigma2 = fit$var['bl', 1]),
                  fam = list(nlevels = 63,
                             sigma2 = fit$var['fam', 1])),
    residual.variance = fit$var['Residual', 1],
    N =
  )
}

## ----heritability-competition, warning = FALSE---------------------------
res.cm <- remlf90(fixed   = phe_X ~ 1,
                 genetic = list(model = 'competition',
                                pedigree = globulus[, 1:3],
                                id = 'self',
                                coord = globulus[, c('x','y')],
                                competition_decay = 1),
                 method = 'em',
                 data = globulus)

summary(res.cm)

