#' 
#' 
## ----include = FALSE-----------------------------------------------------
## Lab excercises for the breedR workshop held in Orléans 2018-09-18
## http://famuvie.github.io/breedR/
## (c) 2018 Facundo Muñoz
## facundo.munoz@cirad.fr, @famuvie
## 
## This material is provided under a Creative Commons Attribution 4.0
## International License (http://creativecommons.org/licenses/by/4.0/).

#' 
#' 
#' ## 0. Setup
#' 
#' Start by loading all the packages you need. We will surely need
#' `breedR`. But you might want to use some other packages for plotting
#' or data manipulation.
#' 
## ------------------------------------------------------------------------
# library(···)
# ···

#' 
#' 
#' 
#' ## 1. Simple progeny test
#' 
#' Here is a template for the breedR function to fit a simple progeny
#' test with response variable `y` and grouping variable `g` in dataset
#' `D`. Use variables `phe_X` as response and `mum` as grouping variable
#' from the `globulus` dataset (included with `breedR`)
#' 
#' 
## ------------------------------------------------------------------------

# fm0 <- remlf90(
#   fixed = y ~ 1,
#   random = ~ g,
#   data = D)

#' 
#' 
#' 
#' 
#' ## 2. Include further effects
#' 
#' 1. Extend fm0 by including a fixed effect of the provenance (variable gg)
#' and a random block effect (variable bl).
#' 
#' 2. Specify sensible initial variances for the random component
#' 
## ------------------------------------------------------------------------

# fm1 <- remlf90(
#   ···,
#   var.ini = list(···, resid = ···)
# )

#' 
#' 
#' 
#' 
#' 3. Extend fm1 by including an interaction between cross-classified
#' variables
#' 
## ------------------------------------------------------------------------

# fm2 <- remlf90(···)

#' 
#' 
#' 
#' 
#' ## 3. Extract results
#' 
#' 1. Use functions summary(), fixef() and ranef() to extract estimates
#' 
#' 2. Variance estimates are stored in fm$var
#' 
#' 3. Plot observed phenotype and residual()s vs fitted() values assess
#' the model predictive ability and to diagnose residuals
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' ## 4. Pedigrees
#' 
#' 
#' 1. Replace the genetic variable `mum` at _family_ level, by an _animal
#' model_ with a genetic effect at _individual_ level.
#' 
#' Help: `RShowDoc("Handling-pedigrees", package = "breedR")`
#' 
## ------------------------------------------------------------------------

# fm3 <- remlf90(
#   fixed = ···,
#   random = ···,
#   genetic = list(
#     model = 'add_animal',  # model name for the term
#     pedigree = ···,        # pedigree (see Details in ?remlf90)
#     id = ···),             # variable name of the individual
#   data = globulus
# )


#' 
#' 
#' 
#' 2. Retrieve the predicted individual breeding values. Make sure they
#' are in the same order as observed in the globulus dataset.
#' 
## ------------------------------------------------------------------------
# ranef(fm3)$genetic
## Here are the breeding values of observed and unobserved indivuduals
## Use model.matrix(fm3)$genetic to get the incidence matrix
## and combine appropriately

#' 
#' 
#' 
#' ## 5. Heritability
#' 
#' 1. Compute the heritability of the globulus dataset using the three
#' available methods. See: `RShowDoc("Heritability", package =
#' "breedR")`.
#' 
#' 
#' ### Method 1: using a `genetic` term automatically yields a heritability
#' 
## ------------------------------------------------------------------------
## It's done!! check 
# summary(fm3)

## Can you discover how to extract the numeric value (and SE) from the
## object?

#' 
#' 
#' 
#' ### Method 2: using custom formulae
#' 
#' 
## ------------------------------------------------------------------------
## Work out the formula for heritability from model terms
## 
## For single-trait models,
## every term is G_i_i_1_1 where i is the index of the term
## except for the residual term which is R_1_1
## 

## Translate the formula into a character string with the format above
# h2fml <- "···"

## Ask breedR to compute estimates for that quantity using
## `progsf90.options`
# fm3.1 <- remlf90(
#   fixed = ···,
#   random = ···,
#   genetic = ···,
#   progsf90.options = paste('se_covar_function h2', h2fml),
#   data = globulus
# )


#' 
#' 
#' 
#' 
#' 
#' ### Method 3: using _Bootstrap_ estimation
#' 
#' 1. Fit the model to your data (DONE: fm3).
#' 
#' 2. Write a function to simulate observations from the fitted model.
#' 
#'     You can use `breedR.sample.phenotype()` if the model is simple enough
#' 
#' 3: Write a function to fit a simulated dataset and extract the target
#' values
#' 
#' 
## ----data-simulation-function--------------------------------------------

# resample_globulus <- function(fit) {
#   ## Use the estimated values in fit to produce a new data.frame
#   ## of the same size and with the same variables as globulus.
#   return(dat)
# }

#' 
#' 
## ----sample-estimates----------------------------------------------------

# sim_target() <- function(dat) {
#   ## Fit the same model as fm3 to this fake dataset dat
#   ## Return the point estimates of all variances and heritability
#   return(estimates)
# }

#' 
#' 
#' 
#' 
#' 
#' 
## ----boot-estimates------------------------------------------------------
## Replicate the data-generation+estimation process many times
## Warning: this can take a while, depending on the model and the
## dataset.
boot_estimates <- function(N, fit) {
  ans <- replicate(N, sim_target(dat = resample_globulus(fit)))
  return(as.data.frame(t(ans)))
}

empirical_dist <- boot_estimates(N = 100, fit = fm3)

#' 
#' 
#' 
#' 
#' 
#' 
#' ## 6. Spatial effects
#' 
#' 1. Fit an animal model without the `blocks` effect
#' 
## ------------------------------------------------------------------------
# fm4 <- remlf90(···)

#' 
#' 
#' 
#' 2. Asess the spatial independence of residuals by 
#' 
#'     - plotting their spatial distribution
#'     
#'     - interpreting the variogram of residuals
#' 
## ------------------------------------------------------------------------

## You can simply use the plot() function, specifying type =
## "residuals" See ?plot.remlf90
## 
## If you get an error, please read the super-informative error
## message and fix it!

#' 
## ------------------------------------------------------------------------

## For the variogram of residuals, I'll let you guess the function
## name.

#' 
#' 
#' 
#' 
#' 
#' 3. Extend `fm4` with each of the three possible spatial models in `breedR`
#' 
## ------------------------------------------------------------------------

# fm5 <- list(
#   bl = remlf90(
#     ···
#     spatial = list(
#       model = 'blocks',  # spatial model name
#       coord = ···,       # matrix or data.frame with coordinates
#       id = 'bl'),        # name of the variable
#     data    = globulus
#   ),
#   sp = remlf90(
#     ···
#     spatial = list(
#       model   = 'splines',  # spatial model name
#       coord   = ···         # matrix or data.frame with coordinates
#       n.knots = ···         # number of internal knots in each dim
#     ), 
#     data    = globulus,
#     method  = 'em'          # `ai` does not like splines
#   ),
#   ar = remlf90(
#     fixed   = phe_X ~ gg,
#     genetic = gen.globulus, 
#     spatial = list(
#       model = 'AR',      # spatial model name
#       coord = ···,       # matrix or data.frame with coordinates
#       rho   = ···        # autocorrelation coefficient in each dim
#     ), 
#     data    = globulus
#   )
# )  


#' 
#' 
#' 
#' 4. Plot and compare the predicted spatial effect from each model
#' 
## ------------------------------------------------------------------------

## You can simply use the plot() function with type = "spatial" 
## (also "fullspatial", check the difference).
## 
## In order to compare the three plots under the same scale, use
## compare.plots(list(p1, p2, p3)). See `?compare.plots`.
## 

#' 
#' 
#' 
#' 5. Plot and compare the residuals from the animal model without
#' spatial effect (`fm4`) and from the three spatial models (`fm5`).
#' 
#' 
#' 
#' 
#' 
#' 
#' ## 7. Genotype-Environment interaction in multi-site trials
#' 
#' Here we are using the `douglas` dataset, included with `breedR`,
#' which is a 3-site trial with shared genetic material.
#' 
#' For comparison, let's first fit a _reference_ model without
#' interaction.
#' 
#' 1. Fit a __reference__ model for the variable `C13` with fixed effects
#' of provenance (`orig`) and site (`site`) and a random family (`mum`)
#' effect
#' 
## ------------------------------------------------------------------------

# fm7.0 <- remlf90(
#   ···
# )

#' 
#' 
#' 2. Fit a simple interaction model with constant variance accross sites.
#' 
## ------------------------------------------------------------------------

# fm7.1 <- remlf90(
#   ···
# )

#' 
#' 
#' 
#' 
#' 3. Extend the previous model to account for site-varying interaction
#' variances.
#' 
## ------------------------------------------------------------------------
## 1. Create dummy variables for the families on each site,
## that are 0 or NA in the other sites.
## 
## 2. Fit the model using a main family effect and three site-specific
## interaction effects

#' 
#' 
#' 
#' 4. Examine and compare the site-specific breeding values from each
#' of the three models above
#' 
#' 
## ------------------------------------------------------------------------
## Each of the terms of the differents models will possibly have a
## different number of levels. Be very careful in keeping the right
## order to make values comparable.
##
## A safe practice is to pre-multiply the random effects by the
## incidence matrix (`model.matrix()`) to retrieve the values in the
## ordering of the original dataset.
##
## Do that for each of the models, and then filter out duplicate lines
## using `unique()`.

#' 
#' 
