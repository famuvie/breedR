### Test the auxiliar functions in utils.R ###


context("Auxiliar functions")

